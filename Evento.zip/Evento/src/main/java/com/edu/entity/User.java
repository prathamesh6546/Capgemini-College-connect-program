package com.edu.entity;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

@Entity
public class User {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userid;
	
	private String username;
	
	@Pattern(regexp = "^[6-9]\\d{9}$") 
	private String userphoneno;
	@Column(nullable = false)
	@Email(regexp="^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}")
	private String useremail;
	
	private String usercollege;
	
	private String userpassword;
	
	 private Date userjoingdate;
	 
	 @OneToMany(mappedBy = "user")
	    List<Event> user=new ArrayList<Event>();


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String username, @Pattern(regexp = "^[6-9]\\d{9}$") String userphoneno,
			@Email(regexp = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}") String useremail, String usercollege,
			String userpassword, Date userjoingdate) {
		super();
		this.username = username;
		this.userphoneno = userphoneno;
		this.useremail = useremail;
		this.usercollege = usercollege;
		this.userpassword = userpassword;
		this.userjoingdate = userjoingdate;
	}

	public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserphoneno() {
		return userphoneno;
	}

	public void setUserphoneno(String userphoneno) {
		this.userphoneno = userphoneno;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUsercollege() {
		return usercollege;
	}

	public void setUsercollege(String usercollege) {
		this.usercollege = usercollege;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public Date getUserjoingdate() {
		return userjoingdate;
	}

	public void setUserjoingdate(Date userjoingdate) {
		this.userjoingdate = userjoingdate;
	}
	

	public List<Event> getUser() {
		return user;
	}

	public void setUser(List<Event> user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "User [userid=" + userid + ", username=" + username + ", userphoneno=" + userphoneno + ", useremail="
				+ useremail + ", usercollege=" + usercollege + ", userpassword=" + userpassword + ", userjoingdate="
				+ userjoingdate + "]";
	}
	 
	 

}
