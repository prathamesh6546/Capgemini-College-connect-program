package com.edu.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;


@Entity
public class Sponser {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sponserid;
     
	private String sponsername;
	
	private String sponserdescription;
	@Pattern(regexp = "^[6-9]\\d{9}$") 
	private String sponserphoneno;
	@Column(nullable = false)
	@Email(regexp="^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}")
	private String sponseremail;
	
	
	@Column(nullable = false)
	private String sponserpassword;
	
	 private Date sponserjoingdate;

	public Sponser() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sponser(String sponsername, @Pattern(regexp = "^[6-9]\\d{9}$") String sponserphoneno,
			@Email(regexp = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}") String sponseremail,
			String sponserdescription, String sponserpassword, Date sponserjoingdate) {
		super();
		this.sponsername = sponsername;
		this.sponserphoneno = sponserphoneno;
		this.sponseremail = sponseremail;
		this.sponserdescription = sponserdescription;
		this.sponserpassword = sponserpassword;
		this.sponserjoingdate = sponserjoingdate;
	}

	public Long getSponserid() {
		return sponserid;
	}

	public void setSponserid(Long sponserid) {
		this.sponserid = sponserid;
	}

	public String getSponsername() {
		return sponsername;
	}

	public void setSponsername(String sponsername) {
		this.sponsername = sponsername;
	}

	public String getSponserphoneno() {
		return sponserphoneno;
	}

	public void setSponserphoneno(String sponserphoneno) {
		this.sponserphoneno = sponserphoneno;
	}

	public String getSponseremail() {
		return sponseremail;
	}

	public void setSponseremail(String sponseremail) {
		this.sponseremail = sponseremail;
	}

	public String getSponserdescription() {
		return sponserdescription;
	}

	public void setSponserdescription(String sponserdescription) {
		this.sponserdescription = sponserdescription;
	}

	public String getSponserpassword() {
		return sponserpassword;
	}

	public void setSponserpassword(String sponserpassword) {
		this.sponserpassword = sponserpassword;
	}

	public Date getSponserjoingdate() {
		return sponserjoingdate;
	}

	public void setSponserjoingdate(Date sponserjoingdate) {
		this.sponserjoingdate = sponserjoingdate;
	}

	@Override
	public String toString() {
		return "Sponser [sponserid=" + sponserid + ", sponsername=" + sponsername + ", sponserphoneno=" + sponserphoneno
				+ ", sponseremail=" + sponseremail + ", sponserdescription=" + sponserdescription + ", sponserpassword="
				+ sponserpassword + ", sponserjoingdate=" + sponserjoingdate + "]";
	}
	 
	 
	 
	 

	
	
	
}
