package com.edu.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Event {
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private long eventid;
    
    private String eventname;
    
    private String location;
    
    private Date startevent;
    
    private Date endevent;
    
    @JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "userid",referencedColumnName = "userid")
    User user;
    

	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Event(String eventname, String location, Date startevent, Date endevent) {
		super();
		this.eventname = eventname;
		this.location = location;
		this.startevent = startevent;
		this.endevent = endevent;
	}

	public long getEventid() {
		return eventid;
	}

	public void setEventid(long eventid) {
		this.eventid = eventid;
	}

	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getStartevent() {
		return startevent;
	}

	public void setStartevent(Date startevent) {
		this.startevent = startevent;
	}

	public Date getEndevent() {
		return endevent;
	}

	public void setEndevent(Date endevent) {
		this.endevent = endevent;
	}
	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Event [eventid=" + eventid + ", eventname=" + eventname + ", location=" + location + ", startevent="
				+ startevent + ", endevent=" + endevent + "]";
	}

	public void assigneventtouser(User user2) {
		// TODO Auto-generated method stub
		this.user=user2;
		
	}
    
    
    
    
    
    

}
