package com.edu.service;

import java.util.List;

import com.edu.entity.Sponser;

public interface SponserService {

public Sponser	addAdmin(Sponser sponser);

public Sponser findSponserEmail(String sponseremail);


public Sponser verifySponser(String sponseremail, String sponserpassword);

public List<Sponser> deleteById(Long sponserid);

public Sponser updateSponser(Long sponserid, Sponser sponser);

public List<Sponser> getAllSponser();

}
