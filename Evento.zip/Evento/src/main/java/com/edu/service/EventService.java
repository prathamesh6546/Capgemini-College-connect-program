package com.edu.service;

import java.util.List;

import com.edu.entity.Event;

public interface EventService  {

  Event addEvent(Event event);

List<Event> getAllEvent();

List<Event> deleteById(Long eventid);

Event updateEvent(Long eventid, Event event);

void assigneventtouser(long eventid, Long userid);

}
