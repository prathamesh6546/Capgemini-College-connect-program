package com.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.entity.Sponser;
import com.edu.repository.SponserRepository;

@Service
public class SponserServiceImpl implements SponserService {

	@Autowired
	private SponserRepository sponserRepository;

	@Override
	public Sponser addAdmin(Sponser sponser) {
		// TODO Auto-generated method stub
		return sponserRepository.save(sponser);
	}

	@Override
	public Sponser findSponserEmail(String sponseremail) {
		// TODO Auto-generated method stub
		return sponserRepository.findSponserEmail(sponseremail);
	}

	@Override
	public Sponser verifySponser(String sponseremail, String sponserpassword) {
		// TODO Auto-generated method stub
		return sponserRepository.verifySponser(sponseremail,sponserpassword);
	}

	@Override
	public List<Sponser> deleteById(Long sponserid) {
		// TODO Auto-generated method stub
		sponserRepository.deleteById(sponserid);
		return sponserRepository.findAll();
	}

	@Override
	public Sponser updateSponser(Long sponserid, Sponser sponser) {
		// TODO Auto-generated method stub
		Sponser update=sponserRepository.findById(sponserid).get();
		update.setSponsername(sponser.getSponsername());
		update.setSponserphoneno(sponser.getSponserphoneno());
		update.setSponseremail(sponser.getSponseremail());
		update.setSponserdescription(sponser.getSponserdescription());
		update.setSponserpassword(sponser.getSponserpassword());
		update.setSponserjoingdate(sponser.getSponserjoingdate());
        
		sponserRepository.save(update);
		
		return update;
	}

	@Override
	public List<Sponser> getAllSponser() {
		// TODO Auto-generated method stub
		return sponserRepository.findAll();
	}
	
	
}
