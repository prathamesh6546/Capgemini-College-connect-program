package com.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.entity.Sponser;
import com.edu.entity.User;
import com.edu.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	
	@Autowired
	private  UserRepository userRepository;

	@Override
	public User findUserEmail(String useremail) {
		// TODO Auto-generated method stub
		return userRepository.findUserEmail(useremail);
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
		
	}

	@Override
	public User verifyUser(String useremail, String userpassword) {
		// TODO Auto-generated method stub
		return userRepository.verifyUser(useremail,userpassword);
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public List<User> deleteById(Long userid) {
		// TODO Auto-generated method stub
		userRepository.deleteById(userid);
		return userRepository.findAll();
	}

	@Override
	public User updateUser(Long userid, User user) {
		// TODO Auto-generated method stub
		User update=userRepository.findById(userid).get();
		update.setUsername(user.getUsername());
		update.setUserphoneno(user.getUserphoneno());
		update.setUseremail(user.getUseremail());
		update.setUsercollege(user.getUsercollege());
		update.setUserpassword(user.getUserpassword());
		update.setUserjoingdate(user.getUserjoingdate());
		
		userRepository.save(update);
		
		return update;
	}
	
}
