package com.edu.service;

import javax.validation.Valid;

import com.edu.entity.Admin;

public interface AdminService {

	public Admin addAdmin(Admin admin);

	public Admin findAdminemail(String adminemail);

	public Admin verifyAdmin(String adminemail, String password);

}
