package com.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.entity.Event;
import com.edu.entity.User;
import com.edu.repository.EventRepository;
import com.edu.repository.UserRepository;

@Service
public class EventServiceImpl implements EventService{

	
	@Autowired
	private EventRepository eventRepository;

	private UserRepository userRepository;
	
	@Override
	public Event addEvent(Event event) {
		// TODO Auto-generated method stub
		return eventRepository.save(event);
	}

	@Override
	public List<Event> getAllEvent() {
		// TODO Auto-generated method stub
		return eventRepository.findAll();
	}

	@Override
	public List<Event> deleteById(Long eventid) {
		// TODO Auto-generated method stub
		eventRepository.deleteById(eventid);
		return eventRepository.findAll();
	}

	@Override
	public Event updateEvent(Long eventid, Event event) {
		// TODO Auto-generated method stub
		Event update=eventRepository.findById(eventid).get();
		update.setEventname(event.getEventname());
		update.setLocation(event.getLocation());
		update.setStartevent(event.getStartevent());
		update.setEndevent(event.getEndevent());
		
		eventRepository.save(update);
		return update;
	}

	@Override
	public void assigneventtouser(long eventid, Long userid) {
		// TODO Auto-generated method stub
	   	Event event=eventRepository.findById(eventid).get();
	   	User user=userRepository.findById(userid).get();
	   	event.assigneventtouser(user);
	}
}
