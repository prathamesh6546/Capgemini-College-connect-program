package com.edu.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.entity.Admin;
import com.edu.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
 	private AdminRepository adminRepository;

	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
		
	}

	@Override
	public Admin findAdminemail(String adminemail) {
		// TODO Auto-generated method stub
		return adminRepository.findByadminemail(adminemail);
	}

	@Override
	public Admin verifyAdmin(String adminemail, String password) {
		// TODO Auto-generated method stub
		return adminRepository.verifyAdmin(adminemail, password);
	}
	
}
