package com.edu.service;

import java.util.List;

import com.edu.entity.User;

public interface UserService {

	User findUserEmail(String useremail);

	User addUser(User user);

	User verifyUser(String useremail, String userpassword);

	List<User> getAllUser();

	List<User> deleteById(Long userid);

	User updateUser(Long userid, User user);

}
