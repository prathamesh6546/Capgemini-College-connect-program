package com.edu.repository;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edu.entity.Sponser;

@Repository
public interface SponserRepository extends JpaRepository<Sponser, Long>{
    
	
	@Query(value="select * from sponser where sponseremail=?1",nativeQuery = true)
	Sponser findSponserEmail(String sponseremail);
    
	@Query(value="select * from sponser where sponseremail=?1 and sponserpassword=?2",nativeQuery = true)
	Sponser verifySponser(String sponseremail, String sponserpassword);

}
