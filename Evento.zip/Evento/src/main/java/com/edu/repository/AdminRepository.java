package com.edu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edu.entity.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin,Long> {

	@Query(value="select * from admin where adminemail=?1",nativeQuery = true)
	Admin findByadminemail(String adminemail);

	@Query(value="select * from admin where adminemail=?1 and password=?2",nativeQuery = true)
	Admin verifyAdmin(String adminemail, String password);

}
