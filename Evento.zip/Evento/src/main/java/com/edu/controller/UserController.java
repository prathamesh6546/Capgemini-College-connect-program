package com.edu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.entity.Sponser;
import com.edu.entity.User;
import com.edu.service.UserService;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping("/addUser")
    public ResponseEntity<User> addUser(@RequestBody User user)
    {
    	User existingUser =userService.findUserEmail(user.getUseremail());
	    if (existingUser != null) {
	    	System.out.println("already exits");
	        return ResponseEntity.badRequest().body(null); // Return an error response if already registered
    }
	    userService.addUser(user);
   	 return ResponseEntity.status(HttpStatus.CREATED).body(user); // Return the registered request admin
    }
	
	
	@GetMapping("/checkSponserExits/{useremail}/{userpassword}")
    public ResponseEntity<User> checkUserExits(@PathVariable("useremail") String useremail,@PathVariable("userpassword") String userpassword)
    {
      User suceess=userService.verifyUser(useremail,userpassword);
      if(suceess!=null) {
    	  System.out.println("admin exists");
    	  System.out.println(suceess);
          return ResponseEntity.status(HttpStatus.ACCEPTED).body(suceess);
      }
      else {
    	  System.out.println("not exits");
    	  return ResponseEntity.badRequest().body(null);
      }
    }
	
	 @GetMapping("/getAllUser")
	    public List<User> getAllUser(){
	    	return userService.getAllUser();
	    	
	    }
	   
	
	@DeleteMapping("/deletebyid/{userid}")
    public List<User> deleteById(@PathVariable("userid") Long userid){
    	return userService.deleteById(userid);
    }
    
	@PutMapping("/updateUser/{userid}")
    public User updateUser(@PathVariable("userid") Long userid,@RequestBody User user) {
    	return userService.updateUser(userid,user);
    	
    }

	

	
}
