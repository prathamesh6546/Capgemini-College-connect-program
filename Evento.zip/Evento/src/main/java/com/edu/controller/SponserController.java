package com.edu.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.edu.entity.Sponser;

import com.edu.service.SponserService;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
public class SponserController {
	@Autowired
	private SponserService sponserService;
	
	@PostMapping("/addSponser")
    public ResponseEntity<Sponser> addSponser(@RequestBody Sponser sponser)
    {
    	Sponser existingSponser =sponserService.findSponserEmail(sponser.getSponseremail());
	    if (existingSponser != null) {
	    	System.out.println("already exits");
	        return ResponseEntity.badRequest().body(null); // Return an error response if already registered
    }
		sponserService.addAdmin(sponser);
   	 return ResponseEntity.status(HttpStatus.CREATED).body(sponser); // Return the registered request admin
    }
	
	
	@GetMapping("/checkSponserExits/{sponseremail}/{sponserpassword}")
    public ResponseEntity<Sponser> checkSponserExits(@PathVariable("sponseremail") String sponseremail,@PathVariable("sponserpassword") String sponserpassword)
    {
      Sponser suceess=sponserService.verifySponser(sponseremail,sponserpassword);
      if(suceess!=null) {
    	  System.out.println("admin exists");
    	  System.out.println(suceess);
          return ResponseEntity.status(HttpStatus.ACCEPTED).body(suceess);
      }
      else {
    	  System.out.println("not exits");
    	  return ResponseEntity.badRequest().body(null);
      }
    }
	
	 @GetMapping("/getAllSponser")
	    public List<Sponser> getAllSponser(){
	    	return sponserService.getAllSponser();
	    	
	    }
	   
	
	@DeleteMapping("/deletebyid/{sponserid}")
    public List<Sponser> deleteById(@PathVariable("sponserid") Long sponserid){
    	return sponserService.deleteById(sponserid);
    }
    
	@PutMapping("/updateSponser/{sponserid}")
    public Sponser updateSponser(@PathVariable("sponserid") Long sponserid,@RequestBody Sponser sponser) {
    	return sponserService.updateSponser(sponserid,sponser);
    	
    }

	

}
