package com.edu.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.entity.Admin;
import com.edu.repository.AdminRepository;
import com.edu.service.AdminService;

@CrossOrigin(origins = "http://localhost:8080")//connect with ang

@RestController
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	
	@PostMapping("/addAdmin")
    public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin)
    {
    	Admin existingAdmin =adminService.findAdminemail(admin.getAdminemail());
	    if (existingAdmin != null) {
	    	System.out.println("already exits");
	        return ResponseEntity.badRequest().body(null); // Return an error response if already registered
    }
		adminService.addAdmin(admin);
   	 return ResponseEntity.status(HttpStatus.CREATED).body(admin); // Return the registered request admin
    }
	
	
	@GetMapping("/checkAdminExists/{adminemail}/{password}")
    public ResponseEntity<Admin> checkAdminExists(@PathVariable("adminemail") String adminemail,@PathVariable("password") String password)
    {
      Admin suceess=adminService.verifyAdmin(adminemail,password);
      if(suceess!=null) {
    	  System.out.println("admin exists");
    	  System.out.println(suceess);
          return ResponseEntity.status(HttpStatus.ACCEPTED).body(suceess);
      }
      else {
    	  System.out.println("not exits");
    	  return ResponseEntity.badRequest().body(null);
      }
    }
	
	
}
