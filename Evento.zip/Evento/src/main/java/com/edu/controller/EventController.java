package com.edu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.entity.Event;
import com.edu.service.EventService;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
public class EventController {
	@Autowired
	private EventService eventService;
	
	@PostMapping("/addEvent/{userid}")
	 public ResponseEntity<Event> addEvent(@PathVariable("userid") Long userid,@RequestBody Event event)
	    {
	     eventService.addEvent(event);
	     eventService.assigneventtouser(event.getEventid(),userid);
	     return ResponseEntity.status(HttpStatus.CREATED).body(event); 
	     
	    }
	
	@GetMapping("/getAllEvent")
    public List<Event> getAllEvent(){
    	return eventService.getAllEvent();
    	
    }
 
	@DeleteMapping("/deletebyid/{eventrid}")
    public List<Event> deleteById(@PathVariable("eventid") Long eventid){
    	return eventService.deleteById(eventid);
    }
    
	@PutMapping("/updateEvent/{eventid}")
    public Event updateEvent(@PathVariable("eventid") Long eventid,@RequestBody Event event) {
    	return eventService.updateEvent(eventid,event);
    	
    }

	
	
}
